﻿Agent Mark Hub 0.2.0 - portable build (Windows 10/11, 64-bit)
=============================================================

This folder is the whole application. No installer, no admin rights.

To run: double-click agent-mark-hub.exe
To "install": move this folder somewhere permanent (e.g. C:\Apps\AgentMarkHub)
and create a shortcut to agent-mark-hub.exe.

Keep WebView2Loader.dll next to the .exe - the app will not start without it.

Data is stored in:
  %APPDATA%\org.agentmark.hub\agent-mark-hub\

Delete that folder for a factory reset. Backups are written to its backups\
subfolder and are encrypted.

No internet connection is required. No AI. No telemetry.
Pilot preview: use synthetic data only until the external security audit closes.
